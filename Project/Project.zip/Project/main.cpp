// Mathematics for Computer Graphics Section 01 Group 7
// PROJECT
// Group members name and matric no.:
// MUHAMMAD FARIS BIN ROSLEE A21EC0073
// PARIMALA A/P K.PARAMASIVAM B21EC0051
// LAI KAI CHIAN A21EC0041
// WAI JIA WEN A21EC0139

#include<graphics.h>
#include<conio.h>
#include<dos.h>
#include<iostream>
#include<cmath>
#include<ctime>

#define THREE 3
#define PI 3.14159265

using namespace std;

class Point
{
	private:
		double x, y;
	public:
		Point(double x_ = 0, double y_ = 0)
		{
			setPosition(x_, y_);
		}
		double getX()
		{
			return x;
		}
		double getY()
		{
			return y;
		}
		void setPosition(double x_, double y_)
		{
			x = x_;
			y = y_;
		}
		// 2D Homogeneous Translation
		void T(double dx, double dy)
		{
			x += dx;
    		y += dy;
		}
		// 2D Homogeneous Scaling
		void S(double sx, double sy)
		{
			x *= sx;
			y *= sy;
		}
		void S_pivot(double sx, double sy, double xp, double yp)
		{
			T(-xp, -yp);
			S(sx, sy);
			T(xp, yp);
		}
		// 2D Homogeneous Rotation
		void R(double angle)
		{
			double tempx = x, tempy = y;
    		angle = angle * PI / 180; 
    		x = tempx*cos(angle)-tempy*sin(angle);
    		y = tempx*sin(angle)+tempy*cos(angle);
		}
		void R_pivot(double angle, double xp, double yp)
		{
			T(-xp, -yp);
			R(angle);
			T(xp, yp);
		}
		// 2D Homogeneous Shearing respective to x-axis
		void SHx(double shx)
		{
			x+=shx*y;
		}
		// 2D Homogeneous Shearing respective to y-axis
		void SHy(double shy)
		{
			y+=shy*x;
		}
		void draw(int colour)
		{
			putpixel(x, y, colour);
		}
		void undraw()
		{
			putpixel(x, y, BLACK);
		}
		void I(Point &p, double t, int c)
		{
			Point result;
    		result.x = x*(1-t) + p.x*t;
    		result.y = y*(1-t) + p.y*t;
    		result.draw(c);
		}
		void operator=(Point &p)
		{
			x = p.x;
			y = p.y;
		}
};

class Circle
{
	private:
		double radius;
		int colour;
	public:
        Point p;
		Circle(double x_ = 0, double y_ = 0, double r = 0, int c = 0)
		{
			p.setPosition(x_, y_);
			radius = r;
			colour = c;
		}
		void drawEmpty()
		{
			setcolor(colour);
			circle(p.getX(), p.getY(), radius);
		}
		void undrawEmpty()
		{
			setcolor(BLACK);
			circle(p.getX(), p.getY(), radius);
		}
		void drawFilled()
		{
			setcolor(colour);
		    circle(p.getX(), p.getY(), radius);
		    setfillstyle(SOLID_FILL, colour);
		    fillellipse(p.getX(), p.getY(), radius, radius);
		}
		void undrawFilled()
		{
			setcolor(BLACK);
		    circle(p.getX(), p.getY(), radius);
		    setfillstyle(SOLID_FILL, BLACK);
		    fillellipse(p.getX(), p.getY(), radius, radius);
		}
		void Translation(double dx, double dy)
		{
			delay(250);
			undrawFilled();
			p.T(dx, dy);
			drawFilled();
		}
};

class Rect
{
        int colour;
	public:
        Point p1;
        Point p2;
        Rect(double x1 = 0, double y1 = 0, double x2 = 0, double y2 = 0, int c = 0)
        {
            p1.setPosition(x1, y1);
            p2.setPosition(x2, y2);
            colour = c;
        }
        void drawEmpty()
        {
            setcolor(colour);
            rectangle(p1.getX(), p1.getY(), p2.getX(), p2.getY());
        }
        void undrawEmpty()
        {
            setcolor(BLACK);
            rectangle(p1.getX(), p1.getY(), p2.getX(), p2.getY());
        }
        void drawFilled()
        {
            setcolor(colour);
            rectangle(p1.getX(), p1.getY(), p2.getX(), p2.getY());
            setfillstyle(SOLID_FILL, colour);
            bar(p1.getX(), p1.getY(), p2.getX(), p2.getY());
        }
        void undrawFilled()
        {
            setcolor(BLACK);
            rectangle(p1.getX(), p1.getY(), p2.getX(), p2.getY());
            setfillstyle(SOLID_FILL, BLACK);
            bar(p1.getX(), p1.getY(), p2.getX(), p2.getY());
        }
		void Translation(double dx, double dy)
		{
			delay(500);
			undrawFilled();
			p1.T(dx, dy);
			p2.T(dx, dy);
			drawFilled();
		}
		void Scaling(double sx, double sy, double xp, double yp)
		{
			delay(250);
			undrawFilled();
			p1.S_pivot(sx, sy, xp, yp);
			p2.S_pivot(sx, sy, xp, yp);
			drawFilled();
		}		
};

class Line
{
		int colour;
	public:
        Point p1;
		Point p2;
		Line(double x1 = 0, double y1 = 0, double x2 = 0, double y2 = 0, int c = 0)
		{
			p1.setPosition(x1, y1);
			p2.setPosition(x2, y2);
            colour = c;
		}
        void draw()
        {
            setcolor(colour);
            line(p1.getX(), p1.getY(), p2.getX(), p2.getY());
        }
        void undraw()
        {
            setcolor(BLACK);
            line(p1.getX(), p1.getY(), p2.getX(), p2.getY());
        }
		void Translation(double dx, double dy)
		{
			undraw();
			p1.T(dx, dy);
			p2.T(dx, dy);
			draw();
		}
		void Rotation(double angle, double xp, double yp)
		{
			undraw();
			p1.R_pivot(angle, xp, yp);
			p2.R_pivot(angle, xp, yp);
			draw();
		}
		void Shearing_x(double shx)
		{
			undraw();
			p1.SHx(shx);
			p2.SHx(shx);
			draw();
		}
};

void intro()
{
	setcolor(LIGHTRED);
    outtextxy(20, getmaxy()-200, " GROUP : 7 "); 
    outtextxy(20, getmaxy()-150, " THEME : TOWARDS THE ENDEMIC PHASE OF COVID-19"); 
    delay(5000);
}

void lastmessage()
{
	setcolor(LIGHTMAGENTA);
	outtextxy(getmaxx()/2-180, getmaxy()/2-40, "Be responsible individuals");
	outtextxy(getmaxx()/2-135, getmaxy()/2, "and stay alert to");
	outtextxy(getmaxx()/2-165, getmaxy()/2+40, "WORLD HEALTH ISSUES !!!");

}

void ending()
{
	setcolor(LIGHTRED);
	outtextxy(getmaxx()/2-150, getmaxy()/2-20, "Thank you for watching :)");
	outtextxy(getmaxx()/2-150, getmaxy()/2+20, "Press 'esc' key to EXIT.");
}

int main()
{
	srand(time(0));

    int gd = DETECT, gm, x, y, color, angle = 0;
    struct arccoordstype a, b;
    initgraph(&gd, &gm, "C:\\TC\\BGI");

    settextstyle(10, HORIZ_DIR, 2); // Set the text style and size
    int width = getmaxx();
    int height = getmaxy();
    
	intro();
	Rect blackScreen(0, 0, getmaxx(), getmaxy(), BLACK);// Screen size rectangle to reset screen into BLACK 
	blackScreen.drawFilled();

	// moving earth
	Circle c(0, getmaxy()/2, 100, BLUE);
	c.drawFilled();
	while(c.p.getX()<(getmaxx()/2-20))
	{	
		c.Translation(getmaxx()/16, 0);
	}

	//pandemic
	setcolor(RED);
	outtextxy(getmaxx()/2-55, getmaxy()/2+125, "PANDEMIC");
	for (int i =0; i< 100; i++)
	{
		int num = rand()%160-80;
		int nums = rand()%160-80;
		Circle redDots(getmaxx()/2 + num, getmaxy()/2 + nums , 2.5, RED);
		delay(100);
		redDots.drawFilled();
	}
	//

	delay(1000);
	blackScreen.drawFilled();

	setcolor(YELLOW);
	outtextxy(getmaxx()/2-60, getmaxy()/2, "---NOW---");

	delay(1000);
	blackScreen.drawFilled();

	// endemic
	delay(500);
	c.drawFilled();
	setcolor(GREEN);
	outtextxy(getmaxx()/2-50, getmaxy()/2+125, "ENDEMIC");
	for (int i =0; i< 15; i++)
	{
		int num = rand()%160-80;
		int nums = rand()%160-80;
		Circle greenDots(getmaxx()/2 + num, getmaxy()/2 + nums , 2.5, GREEN);
		delay(50);
		greenDots.drawFilled();
	}

	delay(2000);
	blackScreen.drawFilled();
	//

	setcolor(YELLOW);
	outtextxy(getmaxx()/2-100, getmaxy()/2, "---YOU SHOULD---");

	delay(1000);
	blackScreen.drawFilled();

	// face
	delay(500);
	Circle face(getmaxx()/2, getmaxy()/2, 75, YELLOW);
	Circle eye1(getmaxx()/2-35, getmaxy()/2-30, 10, BLACK);
	Circle eye2(getmaxx()/2+35, getmaxy()/2-30, 10, BLACK);
	face.drawFilled();
	eye1.drawFilled();
	eye2.drawFilled();
	setcolor(RED);
	arc(getmaxx()/2, getmaxy()/2, 180, 0, 50); // mouth
	
	// mask
	Rect mask(getmaxx()/2-75, getmaxy(), getmaxx()/2+75, getmaxy()+75, LIGHTCYAN);
	mask.drawFilled();
	while(mask.p1.getY()>=(getmaxy()/2))
	{	
		mask.Translation(0, -getmaxy()/16);
	}

	setcolor(LIGHTCYAN);
	outtextxy(getmaxx()/2-150, getmaxy()/2+100, "Wear mask in crowded area");
	outtextxy(getmaxx()/2-120, getmaxy()/2+125, "to protect yourself !");

	delay(3000);
	blackScreen.drawFilled();
	//

	// table
	Line table[8] = {Line(getmaxx()/2-200, getmaxy()/2-100, getmaxx()/2+200, getmaxy()/2-100, BROWN), Line(getmaxx()/2-200, getmaxy()/2, getmaxx()/2+200, getmaxy()/2, BROWN),
					 Line(getmaxx()/2-200, getmaxy()/2-100, getmaxx()/2-200, getmaxy()/2, BROWN), Line(getmaxx()/2+200, getmaxy()/2-100, getmaxx()/2+200, getmaxy()/2, BROWN),
					 Line(getmaxx()/2-200, getmaxy()/2-100, getmaxx()/2-200, getmaxy()/2+50, BROWN), Line(getmaxx()/2+200, getmaxy()/2-100, getmaxx()/2+200, getmaxy()/2+50, BROWN),
					 Line(getmaxx()/2-200, getmaxy()/2, getmaxx()/2-200, getmaxy()/2+150, BROWN), Line(getmaxx()/2+200, getmaxy()/2, getmaxx()/2+200, getmaxy()/2+150, BROWN)};

	for(int i=0; i<8; i++)
	{
		table[i].draw();
	}

	delay(500);
	table[0].Shearing_x(0.5);
	table[2].undraw(); table[2].p1.SHx(0.5);
	table[2].draw();
	table[3].undraw(); table[3].p1.SHx(0.5);
	table[3].draw();
	table[4].undraw();
	table[4].p1.setPosition(table[0].p1.getX(), table[0].p1.getY());
	table[4].p2.setPosition(table[0].p1.getX(), table[0].p1.getY()+150);
	table[4].draw();
	table[5].undraw();
	table[5].p1.setPosition(table[0].p2.getX(), table[0].p2.getY());
	table[5].p2.setPosition(table[0].p2.getX(), table[0].p2.getY()+150);
	table[5].draw();
	table[6].draw();
	table[7].draw();
	//

	// sanitizer
	Rect sanitizer[4] = {Rect(getmaxx()/2-5, getmaxy()/2-115, getmaxx()/2+5, getmaxy()/2-95, WHITE), Rect(getmaxx()/2-10, getmaxy()/2-95, getmaxx()/2+10, getmaxy()/2-75, WHITE),
						 Rect(getmaxx()/2-20, getmaxy()/2-75, getmaxx()/2+20, getmaxy()/2-25, WHITE), Rect(getmaxx()/2-18, getmaxy()/2-70, getmaxx()/2+18, getmaxy()/2-27, LIGHTBLUE)};
	delay(500);
	for(int i=0; i<4; i++)
	{
		if(i==2)
		sanitizer[i].drawEmpty();
		else
		sanitizer[i].drawFilled();
	}

	Point droplets[6] = {Point(getmaxx()/2-7, getmaxy()/2-105), Point(getmaxx()/2-27, getmaxy()/2-105), Point(getmaxx()/2-25, getmaxy()/2-115),
						 Point(getmaxx()/2-25, getmaxy()/2-95), Point(getmaxx()/2-23, getmaxy()/2-125), Point(getmaxx()/2-23, getmaxy()/2-85)};

	sanitizer[0].Scaling(1, 0.5, getmaxx()/2, getmaxy()/2-95); // pressed
	sanitizer[3].Scaling(1, 0.9, getmaxx()/2, getmaxy()/2-25);
	for(int i=1; i<6; i++)
	{
		for(double t=0; t<=1; t+=0.10)
		droplets[0].I(droplets[i], t, LIGHTBLUE);
	}
	delay(500);
	sanitizer[0].Scaling(1, 2, getmaxx()/2, getmaxy()/2-95); // unpressed
	for(int i=1; i<6; i++)
	{
		for(double t=0; t<=1; t+=0.10)
		droplets[0].I(droplets[i], t, BLACK);
	}

	sanitizer[0].Scaling(1, 0.5, getmaxx()/2, getmaxy()/2-95); // pressed
	sanitizer[3].Scaling(1, 0.9, getmaxx()/2, getmaxy()/2-25);
	for(int i=1; i<6; i++)
	{
		for(double t=0; t<=1; t+=0.10)
		droplets[0].I(droplets[i], t, LIGHTBLUE);
	}
	delay(500);
	sanitizer[0].Scaling(1, 2, getmaxx()/2, getmaxy()/2-95); // unpressed
	for(int i=1; i<6; i++)
	{
		for(double t=0; t<=1; t+=0.10)
		droplets[0].I(droplets[i], t, BLACK);
	}
	
	setcolor(LIGHTCYAN);
	outtextxy(getmaxx()/2-120, getmaxy()-150, "Keep sanitizing to");
	outtextxy(getmaxx()/2-110, getmaxy()-125, "kill the germs !");

	delay(5000);
	blackScreen.drawFilled();
	//

	// syringe
	Line l[15] = {Line(110,20,140,20,LIGHTGRAY), Line(110,40,140,40,LIGHTGRAY), Line(110,20,110,40,LIGHTGRAY), Line(140,20,140,40,LIGHTGRAY),
				  Line(120,40,120,170,LIGHTGRAY), Line(130,40,130,170,LIGHTGRAY), Line(80,130,170,130,LIGHTGRAY), Line(80,150,170,150,LIGHTGRAY),
				  Line(80,130,80,150,LIGHTGRAY), Line(170,130,170,150,LIGHTGRAY), Line(100,150,100,350,LIGHTGRAY), Line(150,150,150,350,LIGHTGRAY),
				  Line(100,170,150,170,LIGHTGRAY), Line(100,350,150,350,LIGHTGRAY), Line(125,350,125,450,LIGHTGRAY)};
	if(width<getmaxx()&&height<getmaxy())
	{
		for(int i=0; i<15; i++)
		{
			l[i].Translation(200, 150);
		}
	}
	for(int i=0; i<15; i++)
	{
		l[i].draw();
	}
	
	for(int j=0; j<90; j+=5)
	{
		for(int i=0; i<15; i++)
		{
			if(width<getmaxx()&&height<getmaxy())
			l[i].Rotation(-10, 325, 400);
			else
			l[i].Rotation(-10, 125, 250);
		}delay(250);
	}

	for (int i=0; i<5; i++)
	{
		for(int j=0; j<6; j++)
		{
			l[j].Translation(0,-10);
		}
		l[12].Translation(0,-10);
		delay(250);
	}

	setcolor(LIGHTCYAN);
	outtextxy(getmaxx()/2-80, getmaxy()/2-25, "Stay vaccinated to reduce the");
	outtextxy(getmaxx()/2-90, getmaxy()/2, "risk of infection from COVID-19 !");

	delay(5000);
	blackScreen.drawFilled();
	//

	// last message
	lastmessage();

	delay(5000);
	blackScreen.drawFilled();
	//

	// ending
	ending();
	//

    getch();
    closegraph();
    return 0;
}
